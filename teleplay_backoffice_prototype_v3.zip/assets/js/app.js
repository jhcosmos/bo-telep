
document.querySelectorAll('[data-top-tabs]').forEach(group => {
  const btns = group.querySelectorAll('.tab-btn');
  const panels = group.parentElement.querySelectorAll('[data-tab-panel]');
  function activate(key){
    btns.forEach(b => b.classList.toggle('active', b.getAttribute('data-target')===key));
    panels.forEach(p => p.style.display = (p.getAttribute('data-tab-panel')===key)?'block':'none');
  }
  btns.forEach(b => b.addEventListener('click', () => activate(b.getAttribute('data-target'))));
  if(btns[0]) activate(btns[0].getAttribute('data-target'));
});
function tp_parseMoney(txt){txt=(txt||'').replace(/[\u00A0\s]/g,' ').trim();let t=txt.replace(/[^0-9,.-]/g,'');if(t.indexOf(',')>-1 && t.lastIndexOf(',')>t.lastIndexOf('.')){t=t.replace(/\./g,'').replace(',', '.');}else{t=t.replace(/,/g,'');}const v=parseFloat(t);return isNaN(v)?0:v;}
function tp_fmt(n){return Number(n||0).toLocaleString('pt-PT',{minimumFractionDigits:2,maximumFractionDigits:2});}
document.querySelectorAll('table.table[data-sum-cols]').forEach(tbl => {
  const idxs=(tbl.getAttribute('data-sum-cols')||'').split(',').map(s=>parseInt(s.trim(),10)).filter(n=>!isNaN(n));
  if(!idxs.length) return;
  const rows = tbl.tBodies[0]?Array.from(tbl.tBodies[0].rows):[];
  const sums={}; idxs.forEach(i=>sums[i]=0);
  rows.forEach(r => idxs.forEach(i => {const c=r.cells[i]; if(c) sums[i]+=tp_parseMoney(c.textContent);}));
  let tfoot=tbl.tFoot; if(!tfoot){tfoot=tbl.createTFoot();}
  const tr=document.createElement('tr');
  const cols=tbl.tHead?tbl.tHead.rows[tbl.tHead.rows.length-1].cells.length:(rows[0]?.cells.length||0);
  for(let j=0;j<cols;j++){const td=document.createElement('td'); if(j===0){td.textContent='Totais'; td.style.fontWeight='600';} else if(idxs.includes(j)){td.textContent=tp_fmt(sums[j]); td.style.fontWeight='600';} tr.appendChild(td);}
  tfoot.innerHTML=''; tfoot.appendChild(tr);
});
document.querySelectorAll('table.table[data-sum-counts]').forEach(tbl => {
  const idxs=(tbl.getAttribute('data-sum-counts')||'').split(',').map(s=>parseInt(s.trim(),10)).filter(n=>!isNaN(n));
  if(!idxs.length) return;
  const rows = tbl.tBodies[0]?Array.from(tbl.tBodies[0].rows):[];
  const sums={}; idxs.forEach(i=>sums[i]=0);
  rows.forEach(r => idxs.forEach(i => { const c=r.cells[i]; if(c) sums[i]+=parseInt((c.textContent||'0').toString().replace(/\D/g,''))||0; }));
  let tfoot=tbl.tFoot; if(!tfoot){tfoot=tbl.createTFoot();}
  const tr=document.createElement('tr');
  const cols=tbl.tHead?tbl.tHead.rows[tbl.tHead.rows.length-1].cells.length:(rows[0]?.cells.length||0);
  for(let j=0;j<cols;j++){const td=document.createElement('td'); if(j===0){td.textContent='Totais'; td.style.fontWeight='600';} else if(idxs.includes(j)){td.textContent=sums[j]; td.style.fontWeight='600';} tr.appendChild(td);}
  tfoot.appendChild(tr);
});
